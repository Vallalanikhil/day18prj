package com.src;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class ControllerEx {
@RequestMapping(value="/first")
public String Sample() {
	return "display";
}
@RequestMapping(value="/second")
public String Sample1() {
	return "second";
}
}
