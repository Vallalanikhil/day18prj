package com.model;

public class Student {
	
	private int studentid;
	private String studentName;
	private String studentMobileno;
	
	
	public Student(int studentid, String studentName, String studentMobileno) {
		super();
		this.studentid = studentid;
		this.studentName = studentName;
		this.studentMobileno = studentMobileno;
	}


	public int getStudentid() {
		return studentid;
	}


	public String getStudentName() {
		return studentName;
	}


	public String getStudentMobileno() {
		return studentMobileno;
	}


	@Override
	public String toString() {
		return "Student [studentid=" + studentid + ", studentName=" + studentName + ", studentMobileno="
				+ studentMobileno + "]";
	}
	
	
	
}
