package com.src;


import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.Dao.StudentDao;

import com.model.Student;

public class MainClass {

	public static void main(String[] args) {
		
		ApplicationContext context=new ClassPathXmlApplicationContext("ApplicationContext.xml");
		
		StudentDao edao=(StudentDao) context.getBean("studdao");
		Boolean status=edao.saveStudentbyps(new Student(114,"Kanna","9977445544"));
//		if(!status) {
//			System.out.println("values got inserted");
//		}else {
//			System.out.println("cannot insert values");
//		}
//		
//		
//		List<Student> l=edao.getStudent();
//		for(Student s:l) {
//			System.out.println(s);
//		}
		
//		 int status =edao.deleteStudent(new Student(114,"",""));
//			if(status>0) {
//				System.out.println("values got deleted");
//			}else {
//				System.out.println("cannot delete values");
//			}
			
		 status=edao.UpdateStudent(new Student(114,"Kanna",""));
		if(!status) {
			System.out.println("values got updated");
		}else {
			System.out.println("cannot update values");
		}

	}
	

}
