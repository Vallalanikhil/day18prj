package com.Dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCallback;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.model.Student;

public class StudentDao {
	
	private JdbcTemplate jdbctemp;

	public void setJdbctemp(JdbcTemplate jdbctemp) {
		this.jdbctemp = jdbctemp;
	}
	
	public Boolean saveStudentbyps(Student s) {
		String sql="insert into student values(?,?,?)";
		return jdbctemp.execute(sql,new PreparedStatementCallback<Boolean>() {

			@Override
			public Boolean doInPreparedStatement(PreparedStatement ps) throws SQLException, DataAccessException {
				ps.setInt(1,s.getStudentid());
				ps.setString(2,s.getStudentName());
				ps.setString(3,s.getStudentMobileno());	
				return ps.execute();
			}
			
			
		});
		
		
	}
	public int deleteStudent(Student s1) {
		
		String sql2="delete from student where sid=?"+ s1.getStudentid();
		return jdbctemp.update(sql2);
		
	}
	
	public Boolean UpdateStudent(Student s2)
	{
		String sql4 = "UPDATE student "
	            + "SET sid = ? "
	            + "WHERE sname = ?";
		return jdbctemp.execute(sql4,new PreparedStatementCallback<Boolean>()
				{

					@Override
					public Boolean doInPreparedStatement(PreparedStatement ps)
							throws SQLException, DataAccessException {
						// TODO Auto-generated method stub
					
			
			
			ps.setInt(1,s2.getStudentid());
			ps.setString(2,s2.getStudentName());
			
			return ps.execute();
			
			
					}		
				});
	}
	
public List<Student> getStudent(){
		
		String sql3="select * from student";
		ResultSetExtractor rse= new ResultSetExtractor() {

			@Override
			public Object extractData(ResultSet rs) throws SQLException, DataAccessException {
				List<Student> list=new ArrayList<>();
				while(rs.next()) {
					list.add(new Student(rs.getInt(1),rs.getString(2),rs.getString(3)));
				}
				return list;
			}
			
		};
		return (List<Student>) jdbctemp.query(sql3,rse);
		
	}


}

